﻿using MortgageCalculator.Dto;
using MortgageCalculator.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace MortgageCalculator.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var mortgageDetails = GetMortgageDetails().GetAwaiter().GetResult();
            TempData["MortgageDetails"] = mortgageDetails;
            TempData["LoanDetailsModel"] = new LoanDetailsModel();
            return View(new MortgageModel(mortgageDetails));
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public PartialViewResult CalculateMortgage(MortgageModel mortgageModel)
        {
            if (ModelState.IsValid)
            {
                var loanDetails = Calculate(mortgageModel).GetAwaiter().GetResult();
                LoanDetailsModel loanDetailsModel = new LoanDetailsModel()
                {
                    Duration = mortgageModel.Duration,
                    InterestRate = mortgageModel.InterestRate,
                    LoanAmount = mortgageModel.LoanAmount,
                    TotalInterest = loanDetails.TotalInterest,
                    TotalLoan = loanDetails.TotalLoan
                };

                return PartialView("_LoanDetails", loanDetailsModel);
            }

            throw new HttpException("Please enter the correct values..");
        }

        private async Task<IList<Mortgage>> GetMortgageDetails()
        {
            string url = "http://localhost:49608/api/mortgage";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response = await client.GetAsync(url).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();

            // Deserialize the response body.
            string data = await response.Content.ReadAsStringAsync();
            JavaScriptSerializer JSserializer = new JavaScriptSerializer();
            IList<Mortgage> mortgages = JSserializer.Deserialize<List<Mortgage>>(data);
            return mortgages;
        }

        private async Task<LoanDetails> Calculate(MortgageModel mortgage)
        {
            // mortgage?loanAmount=1000&duration=2&name=aaaaa
            string url = "http://localhost:49608/api/mortgage?";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            url = url + "&loanAmount=" + mortgage.LoanAmount.ToString() + "&duration=" + mortgage.Duration.ToString() + "&interestRate=" + mortgage.InterestRate;
            var response = await client.GetAsync(url).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();

            // Deserialize the response body.
            string data = await response.Content.ReadAsStringAsync();
            JavaScriptSerializer JSserializer = new JavaScriptSerializer();
            return JSserializer.Deserialize<LoanDetails>(data);
        }
    }
}